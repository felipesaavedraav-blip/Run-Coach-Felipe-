const { useState, useEffect, useMemo } = React;
function makeIcon(symbol){ return function Icon({size=18,color, ...props}){ return <span {...props} style={{fontSize:size, color: color || 'inherit', lineHeight:1, display:'inline-flex', alignItems:'center', justifyContent:'center'}}>{symbol}</span>; }; }
const Home=makeIcon('⌂'), CalendarIcon=makeIcon('📅'), Activity=makeIcon('🏃'), User=makeIcon('👤'), ChevronRight=makeIcon('›'), ChevronLeft=makeIcon('‹'), Moon=makeIcon('🌙'), Zap=makeIcon('⚡'), AlertTriangle=makeIcon('⚠️'), CheckCircle2=makeIcon('✅'), X=makeIcon('×'), Check=makeIcon('✓'), Flag=makeIcon('🏁'), TrendingUp=makeIcon('📈'), Plus=makeIcon('+'), RotateCcw=makeIcon('↺'), Sparkles=makeIcon('✨'), HeartPulse=makeIcon('♥');
/* =========================================================
   SEED DATA — Felipe's actual 16-week half marathon plan
   (used to pre-populate the app; fully editable afterward)
   ========================================================= */
const SEED_PLAN = [{"date": "2026-07-01", "week": "0", "phase": "Recuperación", "type": "rest", "session": "Descanso total", "pace": "Sin carga", "note": "Hidratar, dormir bien, caminar si quieres.", "carga": "5-8 km aprox., sin gym", "prioridad": "Absorber, no sumar", "subtitle": "Recuperación activa (post-carrera)"}, {"date": "2026-07-02", "week": "0", "phase": "Recuperación", "type": "rest", "session": "Descanso o caminata 20 min", "pace": "Muy suave", "note": "Sin trote todavía.", "carga": "5-8 km aprox., sin gym", "prioridad": "Absorber, no sumar", "subtitle": "Recuperación activa (post-carrera)"}, {"date": "2026-07-03", "week": "0", "phase": "Recuperación", "type": "easy", "session": "3 km trote muy suave (opcional)", "pace": "6:30-7:00/km", "note": "Solo si las piernas están sueltas. Si dudas, descansa.", "carga": "5-8 km aprox., sin gym", "prioridad": "Absorber, no sumar", "subtitle": "Recuperación activa (post-carrera)"}, {"date": "2026-07-04", "week": "0", "phase": "Recuperación", "type": "gym_b", "session": "Movilidad / core 10 min", "pace": "Suave", "note": "Nada de gym con carga.", "carga": "5-8 km aprox., sin gym", "prioridad": "Absorber, no sumar", "subtitle": "Recuperación activa (post-carrera)"}, {"date": "2026-07-05", "week": "0", "phase": "Recuperación", "type": "long", "session": "5 km easy", "pace": "6:20-6:50/km", "note": "Debe sentirse casi aburrido de fácil.", "carga": "5-8 km aprox., sin gym", "prioridad": "Absorber, no sumar", "subtitle": "Recuperación activa (post-carrera)"}, {"date": "2026-07-06", "week": "1", "phase": "Recuperación", "type": "rest", "session": "Descanso + core 10 min", "pace": "Suave", "note": "Plank, dead bug, side plank.", "carga": "21-24 km aprox. + 2 gym livianos", "prioridad": "Domingo = fondo", "subtitle": "Reactivación"}, {"date": "2026-07-07", "week": "1", "phase": "Recuperación", "type": "easy", "session": "5 km easy", "pace": "6:00-6:30/km", "note": "Conversacional, sin mirar el reloj.", "carga": "21-24 km aprox. + 2 gym livianos", "prioridad": "Domingo = fondo", "subtitle": "Reactivación"}, {"date": "2026-07-08", "week": "1", "phase": "Recuperación", "type": "gym_a", "session": "Gym Día A liviano", "pace": "Deload -20% peso", "note": "Mismo circuito, menos carga que en junio.", "carga": "21-24 km aprox. + 2 gym livianos", "prioridad": "Domingo = fondo", "subtitle": "Reactivación"}, {"date": "2026-07-09", "week": "1", "phase": "Recuperación", "type": "easy", "session": "6 km easy", "pace": "6:00-6:30/km", "note": "Todavía sin quality.", "carga": "21-24 km aprox. + 2 gym livianos", "prioridad": "Domingo = fondo", "subtitle": "Reactivación"}, {"date": "2026-07-10", "week": "1", "phase": "Recuperación", "type": "rest", "session": "Descanso", "pace": "Sin carga", "note": "Dormir e hidratar.", "carga": "21-24 km aprox. + 2 gym livianos", "prioridad": "Domingo = fondo", "subtitle": "Reactivación"}, {"date": "2026-07-11", "week": "1", "phase": "Recuperación", "type": "gym_b", "session": "Gym Día B liviano + opcional 3 km", "pace": "Recovery si corres", "note": "Si las piernas están cargadas, no corras.", "carga": "21-24 km aprox. + 2 gym livianos", "prioridad": "Domingo = fondo", "subtitle": "Reactivación"}, {"date": "2026-07-12", "week": "1", "phase": "Recuperación", "type": "long", "session": "10 km easy", "pace": "6:00-6:30/km", "note": "Primer fondo de vuelta. Controlado.", "carga": "21-24 km aprox. + 2 gym livianos", "prioridad": "Domingo = fondo", "subtitle": "Reactivación"}, {"date": "2026-07-13", "week": "2", "phase": "Base", "type": "rest", "session": "Descanso + core 10 min", "pace": "Suave", "note": "", "carga": "28-30 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — semana 1 de progresión"}, {"date": "2026-07-14", "week": "2", "phase": "Base", "type": "easy", "session": "6 km easy + 4 strides", "pace": "5:50-6:30/km", "note": "Strides de 20 seg, relajados.", "carga": "28-30 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — semana 1 de progresión"}, {"date": "2026-07-15", "week": "2", "phase": "Base", "type": "gym_a", "session": "Gym Día A", "pace": "Moderado", "note": "", "carga": "28-30 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — semana 1 de progresión"}, {"date": "2026-07-16", "week": "2", "phase": "Base", "type": "easy", "session": "7 km easy", "pace": "5:50-6:30/km", "note": "Aún sin quality.", "carga": "28-30 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — semana 1 de progresión"}, {"date": "2026-07-17", "week": "2", "phase": "Base", "type": "rest", "session": "Descanso", "pace": "Sin carga", "note": "", "carga": "28-30 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — semana 1 de progresión"}, {"date": "2026-07-18", "week": "2", "phase": "Base", "type": "gym_b", "session": "Gym Día B + opcional 3 km recovery", "pace": "Recovery", "note": "", "carga": "28-30 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — semana 1 de progresión"}, {"date": "2026-07-19", "week": "2", "phase": "Base", "type": "long", "session": "12 km easy", "pace": "5:55-6:30/km", "note": "Terminar con energía, no competir.", "carga": "28-30 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — semana 1 de progresión"}, {"date": "2026-07-20", "week": "3", "phase": "Base", "type": "rest", "session": "Descanso + core", "pace": "Suave", "note": "", "carga": "32-34 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — vuelve la calidad"}, {"date": "2026-07-21", "week": "3", "phase": "Base", "type": "easy", "session": "7 km easy + 4 strides", "pace": "5:50-6:30/km", "note": "", "carga": "32-34 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — vuelve la calidad"}, {"date": "2026-07-22", "week": "3", "phase": "Base", "type": "gym_a", "session": "Gym Día A", "pace": "Moderado", "note": "", "carga": "32-34 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — vuelve la calidad"}, {"date": "2026-07-23", "week": "3", "phase": "Base", "type": "quality", "session": "8 km: 2 km easy + 3 x 1 km + enfriar", "pace": "Reps 4:55-5:05/km", "note": "Recupera 2 min trotando entre reps.", "carga": "32-34 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — vuelve la calidad"}, {"date": "2026-07-24", "week": "3", "phase": "Base", "type": "rest", "session": "Descanso", "pace": "Sin carga", "note": "", "carga": "32-34 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — vuelve la calidad"}, {"date": "2026-07-25", "week": "3", "phase": "Base", "type": "gym_b", "session": "Gym Día B + opcional 3 km recovery", "pace": "Recovery", "note": "", "carga": "32-34 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — vuelve la calidad"}, {"date": "2026-07-26", "week": "3", "phase": "Base", "type": "long", "session": "13 km easy", "pace": "5:55-6:30/km", "note": "", "carga": "32-34 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — vuelve la calidad"}, {"date": "2026-07-27", "week": "4", "phase": "Base", "type": "rest", "session": "Descanso + movilidad", "pace": "Suave", "note": "", "carga": "35-37 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — sube el tempo"}, {"date": "2026-07-28", "week": "4", "phase": "Base", "type": "easy", "session": "7 km easy", "pace": "5:50-6:30/km", "note": "", "carga": "35-37 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — sube el tempo"}, {"date": "2026-07-29", "week": "4", "phase": "Base", "type": "gym_a", "session": "Gym Día A", "pace": "Moderado", "note": "", "carga": "35-37 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — sube el tempo"}, {"date": "2026-07-30", "week": "4", "phase": "Base", "type": "quality", "session": "9 km: 2 km easy + 4 km tempo + 3 km suaves", "pace": "Tempo 5:00-5:10/km", "note": "Control, no carrera.", "carga": "35-37 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — sube el tempo"}, {"date": "2026-07-31", "week": "4", "phase": "Base", "type": "rest", "session": "Descanso", "pace": "Sin carga", "note": "Prioriza sueño.", "carga": "35-37 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — sube el tempo"}, {"date": "2026-08-01", "week": "4", "phase": "Base", "type": "gym_b", "session": "Gym Día B + opcional 3-4 km recovery", "pace": "Muy suave", "note": "", "carga": "35-37 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — sube el tempo"}, {"date": "2026-08-02", "week": "4", "phase": "Base", "type": "long", "session": "14 km easy", "pace": "5:55-6:30/km", "note": "", "carga": "35-37 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — sube el tempo"}, {"date": "2026-08-03", "week": "5", "phase": "Base", "type": "rest", "session": "Descanso", "pace": "Sin carga", "note": "Recuperar del fondo anterior.", "carga": "38-40 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — velocidad controlada"}, {"date": "2026-08-04", "week": "5", "phase": "Base", "type": "easy", "session": "8 km easy + 4 strides", "pace": "5:50-6:30/km", "note": "", "carga": "38-40 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — velocidad controlada"}, {"date": "2026-08-05", "week": "5", "phase": "Base", "type": "gym_a", "session": "Gym Día A", "pace": "Moderado", "note": "", "carga": "38-40 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — velocidad controlada"}, {"date": "2026-08-06", "week": "5", "phase": "Base", "type": "quality", "session": "10 km: 2 km easy + 5 x 1 km + enfriar", "pace": "Reps 4:35-4:50/km", "note": "90 seg trote entre reps.", "carga": "38-40 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — velocidad controlada"}, {"date": "2026-08-07", "week": "5", "phase": "Base", "type": "rest", "session": "Descanso", "pace": "Sin carga", "note": "No agregues cardio extra.", "carga": "38-40 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — velocidad controlada"}, {"date": "2026-08-08", "week": "5", "phase": "Base", "type": "gym_b", "session": "Gym Día B", "pace": "Upper/core", "note": "", "carga": "38-40 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — velocidad controlada"}, {"date": "2026-08-09", "week": "5", "phase": "Base", "type": "long", "session": "15 km easy, últimos 3 km steady", "pace": "Easy + 5:20-5:35/km", "note": "Solo acelera si vas bien.", "carga": "38-40 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — velocidad controlada"}, {"date": "2026-08-10", "week": "6", "phase": "Base", "type": "rest", "session": "Descanso + movilidad", "pace": "Suave", "note": "", "carga": "30-32 km aprox. (descarga)", "prioridad": "Domingo = fondo corto", "subtitle": "Descarga"}, {"date": "2026-08-11", "week": "6", "phase": "Base", "type": "easy", "session": "7 km easy", "pace": "5:55-6:30/km", "note": "", "carga": "30-32 km aprox. (descarga)", "prioridad": "Domingo = fondo corto", "subtitle": "Descarga"}, {"date": "2026-08-12", "week": "6", "phase": "Base", "type": "gym_a", "session": "Gym Día A liviano", "pace": "Deload -20%", "note": "", "carga": "30-32 km aprox. (descarga)", "prioridad": "Domingo = fondo corto", "subtitle": "Descarga"}, {"date": "2026-08-13", "week": "6", "phase": "Base", "type": "easy", "session": "8 km easy + 4 strides", "pace": "5:55-6:30/km", "note": "Sin quality dura esta semana.", "carga": "30-32 km aprox. (descarga)", "prioridad": "Domingo = fondo corto", "subtitle": "Descarga"}, {"date": "2026-08-14", "week": "6", "phase": "Base", "type": "rest", "session": "Descanso", "pace": "Sin carga", "note": "", "carga": "30-32 km aprox. (descarga)", "prioridad": "Domingo = fondo corto", "subtitle": "Descarga"}, {"date": "2026-08-15", "week": "6", "phase": "Base", "type": "gym_b", "session": "Gym Día B liviano", "pace": "Upper/core", "note": "", "carga": "30-32 km aprox. (descarga)", "prioridad": "Domingo = fondo corto", "subtitle": "Descarga"}, {"date": "2026-08-16", "week": "6", "phase": "Base", "type": "long", "session": "12 km easy", "pace": "5:55-6:30/km", "note": "Fondo corto a propósito.", "carga": "30-32 km aprox. (descarga)", "prioridad": "Domingo = fondo corto", "subtitle": "Descarga"}, {"date": "2026-08-17", "week": "7", "phase": "Base", "type": "rest", "session": "Descanso + core", "pace": "Suave", "note": "", "carga": "42-44 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — cierre del bloque base"}, {"date": "2026-08-18", "week": "7", "phase": "Base", "type": "easy", "session": "8 km easy", "pace": "5:50-6:30/km", "note": "", "carga": "42-44 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — cierre del bloque base"}, {"date": "2026-08-19", "week": "7", "phase": "Base", "type": "gym_a", "session": "Gym Día A", "pace": "Moderado", "note": "", "carga": "42-44 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — cierre del bloque base"}, {"date": "2026-08-20", "week": "7", "phase": "Base", "type": "quality", "session": "10 km: 2 km easy + 6 km ritmo mixto + 2 km easy", "pace": "5:05-5:15/km", "note": "", "carga": "42-44 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — cierre del bloque base"}, {"date": "2026-08-21", "week": "7", "phase": "Base", "type": "rest", "session": "Descanso", "pace": "Sin carga", "note": "", "carga": "42-44 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — cierre del bloque base"}, {"date": "2026-08-22", "week": "7", "phase": "Base", "type": "gym_b", "session": "Gym Día B + opcional 4 km recovery", "pace": "Muy suave", "note": "", "carga": "42-44 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — cierre del bloque base"}, {"date": "2026-08-23", "week": "7", "phase": "Base", "type": "long", "session": "16 km easy, últimos 4 km steady", "pace": "Easy + 5:20-5:35/km", "note": "", "carga": "42-44 km aprox.", "prioridad": "Domingo = fondo", "subtitle": "Base — cierre del bloque base"}, {"date": "2026-08-24", "week": "8", "phase": "Específica", "type": "rest", "session": "Descanso + core", "pace": "Suave", "note": "", "carga": "40-42 km aprox.", "prioridad": "Jueves = checkpoint", "subtitle": "Fase específica — checkpoint"}, {"date": "2026-08-25", "week": "8", "phase": "Específica", "type": "easy", "session": "8 km easy", "pace": "5:50-6:30/km", "note": "", "carga": "40-42 km aprox.", "prioridad": "Jueves = checkpoint", "subtitle": "Fase específica — checkpoint"}, {"date": "2026-08-26", "week": "8", "phase": "Específica", "type": "gym_a", "session": "Gym Día A", "pace": "Moderado", "note": "", "carga": "40-42 km aprox.", "prioridad": "Jueves = checkpoint", "subtitle": "Fase específica — checkpoint"}, {"date": "2026-08-27", "week": "8", "phase": "Específica", "type": "quality", "session": "CHECKPOINT: 3 km easy + 5 km a ritmo objetivo + 2 km easy", "pace": "4:55-5:05/km en 5 km", "note": "Anota el tiempo real.", "carga": "40-42 km aprox.", "prioridad": "Jueves = checkpoint", "subtitle": "Fase específica — checkpoint"}, {"date": "2026-08-28", "week": "8", "phase": "Específica", "type": "rest", "session": "Descanso", "pace": "Sin carga", "note": "", "carga": "40-42 km aprox.", "prioridad": "Jueves = checkpoint", "subtitle": "Fase específica — checkpoint"}, {"date": "2026-08-29", "week": "8", "phase": "Específica", "type": "gym_b", "session": "Gym Día B", "pace": "Upper/core", "note": "", "carga": "40-42 km aprox.", "prioridad": "Jueves = checkpoint", "subtitle": "Fase específica — checkpoint"}, {"date": "2026-08-30", "week": "8", "phase": "Específica", "type": "long", "session": "17 km easy", "pace": "5:55-6:30/km", "note": "", "carga": "40-42 km aprox.", "prioridad": "Jueves = checkpoint", "subtitle": "Fase específica — checkpoint"}, {"date": "2026-08-31", "week": "9", "phase": "Específica", "type": "rest", "session": "Descanso", "pace": "Sin carga", "note": "", "carga": "44-46 km aprox.", "prioridad": "Domingo = fondo con ritmo", "subtitle": "Fase específica — bloques largos"}, {"date": "2026-09-01", "week": "9", "phase": "Específica", "type": "easy", "session": "8 km easy + 4 strides", "pace": "5:50-6:30/km", "note": "", "carga": "44-46 km aprox.", "prioridad": "Domingo = fondo con ritmo", "subtitle": "Fase específica — bloques largos"}, {"date": "2026-09-02", "week": "9", "phase": "Específica", "type": "gym_a", "session": "Gym Día A", "pace": "Moderado", "note": "", "carga": "44-46 km aprox.", "prioridad": "Domingo = fondo con ritmo", "subtitle": "Fase específica — bloques largos"}, {"date": "2026-09-03", "week": "9", "phase": "Específica", "type": "quality", "session": "11 km: 2 km easy + 2 x 3 km + enfriar", "pace": "Bloques 4:55-5:05/km", "note": "3 min suave entre bloques.", "carga": "44-46 km aprox.", "prioridad": "Domingo = fondo con ritmo", "subtitle": "Fase específica — bloques largos"}, {"date": "2026-09-04", "week": "9", "phase": "Específica", "type": "rest", "session": "Descanso", "pace": "Sin carga", "note": "", "carga": "44-46 km aprox.", "prioridad": "Domingo = fondo con ritmo", "subtitle": "Fase específica — bloques largos"}, {"date": "2026-09-05", "week": "9", "phase": "Específica", "type": "gym_b", "session": "Gym Día B + opcional 4 km recovery", "pace": "Muy suave", "note": "", "carga": "44-46 km aprox.", "prioridad": "Domingo = fondo con ritmo", "subtitle": "Fase específica — bloques largos"}, {"date": "2026-09-06", "week": "9", "phase": "Específica", "type": "long", "session": "18 km easy, últimos 5 km ritmo mixto", "pace": "Easy + 5:05-5:20/km", "note": "Simula el tramo km 15-21 de carrera.", "carga": "44-46 km aprox.", "prioridad": "Domingo = fondo con ritmo", "subtitle": "Fase específica — bloques largos"}, {"date": "2026-09-07", "week": "10", "phase": "Específica", "type": "rest", "session": "Descanso + core", "pace": "Suave", "note": "", "carga": "46-48 km aprox.", "prioridad": "Domingo = fondo pico", "subtitle": "Fase específica — semana pico"}, {"date": "2026-09-08", "week": "10", "phase": "Específica", "type": "easy", "session": "8 km easy", "pace": "5:50-6:30/km", "note": "", "carga": "46-48 km aprox.", "prioridad": "Domingo = fondo pico", "subtitle": "Fase específica — semana pico"}, {"date": "2026-09-09", "week": "10", "phase": "Específica", "type": "gym_a", "session": "Gym Día A liviano-moderado", "pace": "Sin récords", "note": "Reduce una serie si las piernas están cargadas.", "carga": "46-48 km aprox.", "prioridad": "Domingo = fondo pico", "subtitle": "Fase específica — semana pico"}, {"date": "2026-09-10", "week": "10", "phase": "Específica", "type": "quality", "session": "10 km: 2 km easy + 3 x 2 km + enfriar", "pace": "4:55-5:05/km", "note": "", "carga": "46-48 km aprox.", "prioridad": "Domingo = fondo pico", "subtitle": "Fase específica — semana pico"}, {"date": "2026-09-11", "week": "10", "phase": "Específica", "type": "rest", "session": "Descanso", "pace": "Sin carga", "note": "Llegar bien al fin de semana.", "carga": "46-48 km aprox.", "prioridad": "Domingo = fondo pico", "subtitle": "Fase específica — semana pico"}, {"date": "2026-09-12", "week": "10", "phase": "Específica", "type": "gym_b", "session": "Gym Día B", "pace": "Upper/core", "note": "", "carga": "46-48 km aprox.", "prioridad": "Domingo = fondo pico", "subtitle": "Fase específica — semana pico"}, {"date": "2026-09-13", "week": "10", "phase": "Específica", "type": "long", "session": "19 km easy, últimos 5 km steady", "pace": "Easy + 5:20-5:30/km", "note": "El fondo más largo del bloque.", "carga": "46-48 km aprox.", "prioridad": "Domingo = fondo pico", "subtitle": "Fase específica — semana pico"}, {"date": "2026-09-14", "week": "11", "phase": "Específica", "type": "rest", "session": "Descanso", "pace": "Sin carga", "note": "", "carga": "34-36 km aprox. (descarga)", "prioridad": "Domingo = fondo corto", "subtitle": "Descarga antes del cierre"}, {"date": "2026-09-15", "week": "11", "phase": "Específica", "type": "easy", "session": "7 km easy", "pace": "5:55-6:30/km", "note": "", "carga": "34-36 km aprox. (descarga)", "prioridad": "Domingo = fondo corto", "subtitle": "Descarga antes del cierre"}, {"date": "2026-09-16", "week": "11", "phase": "Específica", "type": "gym_a", "session": "Gym Día A liviano", "pace": "Deload", "note": "", "carga": "34-36 km aprox. (descarga)", "prioridad": "Domingo = fondo corto", "subtitle": "Descarga antes del cierre"}, {"date": "2026-09-17", "week": "11", "phase": "Específica", "type": "quality", "session": "9 km: 2 km easy + 5 km tempo continuo + 2 km easy", "pace": "4:55-5:05/km", "note": "Tempo continuo, no repeticiones.", "carga": "34-36 km aprox. (descarga)", "prioridad": "Domingo = fondo corto", "subtitle": "Descarga antes del cierre"}, {"date": "2026-09-18", "week": "11", "phase": "Específica", "type": "rest", "session": "Descanso", "pace": "Sin carga", "note": "", "carga": "34-36 km aprox. (descarga)", "prioridad": "Domingo = fondo corto", "subtitle": "Descarga antes del cierre"}, {"date": "2026-09-19", "week": "11", "phase": "Específica", "type": "gym_b", "session": "Gym Día B liviano", "pace": "Upper/core", "note": "", "carga": "34-36 km aprox. (descarga)", "prioridad": "Domingo = fondo corto", "subtitle": "Descarga antes del cierre"}, {"date": "2026-09-20", "week": "11", "phase": "Específica", "type": "long", "session": "14 km easy", "pace": "5:55-6:30/km", "note": "", "carga": "34-36 km aprox. (descarga)", "prioridad": "Domingo = fondo corto", "subtitle": "Descarga antes del cierre"}, {"date": "2026-09-21", "week": "12", "phase": "Específica", "type": "rest", "session": "Descanso + core", "pace": "Suave", "note": "", "carga": "42-44 km aprox.", "prioridad": "Domingo = ensayo de carrera", "subtitle": "Ensayo general"}, {"date": "2026-09-22", "week": "12", "phase": "Específica", "type": "easy", "session": "8 km easy + 4 strides", "pace": "5:50-6:30/km", "note": "", "carga": "42-44 km aprox.", "prioridad": "Domingo = ensayo de carrera", "subtitle": "Ensayo general"}, {"date": "2026-09-23", "week": "12", "phase": "Específica", "type": "gym_a", "session": "Gym Día A", "pace": "Moderado", "note": "", "carga": "42-44 km aprox.", "prioridad": "Domingo = ensayo de carrera", "subtitle": "Ensayo general"}, {"date": "2026-09-24", "week": "12", "phase": "Específica", "type": "quality", "session": "10 km: 2 km easy + 6 km ritmo objetivo continuo + 2 km easy", "pace": "4:55-5:05/km", "note": "Ensayo de ritmo de carrera.", "carga": "42-44 km aprox.", "prioridad": "Domingo = ensayo de carrera", "subtitle": "Ensayo general"}, {"date": "2026-09-25", "week": "12", "phase": "Específica", "type": "rest", "session": "Descanso", "pace": "Sin carga", "note": "", "carga": "42-44 km aprox.", "prioridad": "Domingo = ensayo de carrera", "subtitle": "Ensayo general"}, {"date": "2026-09-26", "week": "12", "phase": "Específica", "type": "gym_b", "session": "Gym Día B + opcional 3 km", "pace": "Muy suave", "note": "", "carga": "42-44 km aprox.", "prioridad": "Domingo = ensayo de carrera", "subtitle": "Ensayo general"}, {"date": "2026-09-27", "week": "12", "phase": "Específica", "type": "long", "session": "18 km easy, últimos 6 km a ritmo objetivo", "pace": "Easy + 4:55-5:05/km", "note": "Ensayo general completo: gel/agua y ropa de carrera.", "carga": "42-44 km aprox.", "prioridad": "Domingo = ensayo de carrera", "subtitle": "Ensayo general"}, {"date": "2026-09-28", "week": "13", "phase": "Taper", "type": "rest", "session": "Descanso", "pace": "Sin carga", "note": "", "carga": "32-34 km aprox.", "prioridad": "Bajar volumen, no intensidad", "subtitle": "Empieza el taper"}, {"date": "2026-09-29", "week": "13", "phase": "Taper", "type": "easy", "session": "7 km easy", "pace": "5:55-6:30/km", "note": "", "carga": "32-34 km aprox.", "prioridad": "Bajar volumen, no intensidad", "subtitle": "Empieza el taper"}, {"date": "2026-09-30", "week": "13", "phase": "Taper", "type": "gym_a", "session": "Gym Día A liviano", "pace": "Deload", "note": "", "carga": "32-34 km aprox.", "prioridad": "Bajar volumen, no intensidad", "subtitle": "Empieza el taper"}, {"date": "2026-10-01", "week": "13", "phase": "Taper", "type": "quality", "session": "8 km: 2 km easy + 4 km ritmo objetivo + 2 km easy", "pace": "4:55-5:05/km", "note": "", "carga": "32-34 km aprox.", "prioridad": "Bajar volumen, no intensidad", "subtitle": "Empieza el taper"}, {"date": "2026-10-02", "week": "13", "phase": "Taper", "type": "rest", "session": "Descanso", "pace": "Sin carga", "note": "", "carga": "32-34 km aprox.", "prioridad": "Bajar volumen, no intensidad", "subtitle": "Empieza el taper"}, {"date": "2026-10-03", "week": "13", "phase": "Taper", "type": "gym_b", "session": "Gym Día B liviano", "pace": "Upper/core", "note": "", "carga": "32-34 km aprox.", "prioridad": "Bajar volumen, no intensidad", "subtitle": "Empieza el taper"}, {"date": "2026-10-04", "week": "13", "phase": "Taper", "type": "long", "session": "14 km easy", "pace": "5:55-6:30/km", "note": "", "carga": "32-34 km aprox.", "prioridad": "Bajar volumen, no intensidad", "subtitle": "Empieza el taper"}, {"date": "2026-10-05", "week": "14", "phase": "Taper", "type": "rest", "session": "Descanso", "pace": "Sin carga", "note": "", "carga": "24-26 km aprox.", "prioridad": "Descansar de verdad", "subtitle": "Taper — sigue bajando"}, {"date": "2026-10-06", "week": "14", "phase": "Taper", "type": "easy", "session": "6 km easy", "pace": "5:55-6:30/km", "note": "", "carga": "24-26 km aprox.", "prioridad": "Descansar de verdad", "subtitle": "Taper — sigue bajando"}, {"date": "2026-10-07", "week": "14", "phase": "Taper", "type": "gym_a", "session": "Gym Día A muy liviano o solo movilidad", "pace": "Ligero", "note": "Evitar agujetas.", "carga": "24-26 km aprox.", "prioridad": "Descansar de verdad", "subtitle": "Taper — sigue bajando"}, {"date": "2026-10-08", "week": "14", "phase": "Taper", "type": "quality", "session": "7 km: 2 km easy + 3 km ritmo objetivo + 2 km easy", "pace": "4:55-5:05/km", "note": "Recordatorio de ritmo, no test.", "carga": "24-26 km aprox.", "prioridad": "Descansar de verdad", "subtitle": "Taper — sigue bajando"}, {"date": "2026-10-09", "week": "14", "phase": "Taper", "type": "rest", "session": "Descanso", "pace": "Sin carga", "note": "Dormir e hidratar.", "carga": "24-26 km aprox.", "prioridad": "Descansar de verdad", "subtitle": "Taper — sigue bajando"}, {"date": "2026-10-10", "week": "14", "phase": "Taper", "type": "gym_b", "session": "Gym Día B muy liviano/core", "pace": "Ligero", "note": "", "carga": "24-26 km aprox.", "prioridad": "Descansar de verdad", "subtitle": "Taper — sigue bajando"}, {"date": "2026-10-11", "week": "14", "phase": "Taper", "type": "long", "session": "10 km easy", "pace": "5:55-6:30/km", "note": "", "carga": "24-26 km aprox.", "prioridad": "Descansar de verdad", "subtitle": "Taper — sigue bajando"}, {"date": "2026-10-12", "week": "15", "phase": "Taper", "type": "rest", "session": "Descanso + movilidad", "pace": "Suave", "note": "", "carga": "16-18 km aprox.", "prioridad": "Frescura sobre todo", "subtitle": "Taper profundo"}, {"date": "2026-10-13", "week": "15", "phase": "Taper", "type": "easy", "session": "5 km easy + 4 strides", "pace": "5:55-6:30/km", "note": "Activar piernas sin fatigar.", "carga": "16-18 km aprox.", "prioridad": "Frescura sobre todo", "subtitle": "Taper profundo"}, {"date": "2026-10-14", "week": "15", "phase": "Taper", "type": "gym_a", "session": "Movilidad / core muy suave", "pace": "Ligero", "note": "Evitar agujetas.", "carga": "16-18 km aprox.", "prioridad": "Frescura sobre todo", "subtitle": "Taper profundo"}, {"date": "2026-10-15", "week": "15", "phase": "Taper", "type": "quality", "session": "5 km: 2 km easy + 2 km ritmo objetivo + 1 km easy", "pace": "4:55-5:05/km", "note": "Recordatorio, no test.", "carga": "16-18 km aprox.", "prioridad": "Frescura sobre todo", "subtitle": "Taper profundo"}, {"date": "2026-10-16", "week": "15", "phase": "Taper", "type": "rest", "session": "Descanso", "pace": "Sin carga", "note": "Dormir e hidratar.", "carga": "16-18 km aprox.", "prioridad": "Frescura sobre todo", "subtitle": "Taper profundo"}, {"date": "2026-10-17", "week": "15", "phase": "Taper", "type": "easy", "session": "Opcional 20-25 min muy suave o descanso total", "pace": "Muy suave", "note": "Elige descanso si hay dudas.", "carga": "16-18 km aprox.", "prioridad": "Frescura sobre todo", "subtitle": "Taper profundo"}, {"date": "2026-10-18", "week": "15", "phase": "Taper", "type": "long", "session": "8 km easy", "pace": "5:55-6:30/km", "note": "", "carga": "16-18 km aprox.", "prioridad": "Frescura sobre todo", "subtitle": "Taper profundo"}, {"date": "2026-10-19", "week": "16", "phase": "Carrera", "type": "rest", "session": "Descanso + movilidad ligera", "pace": "Suave", "note": "Nada de fuerza dura.", "carga": "14-16 km incluyendo carrera", "prioridad": "Sábado = carrera", "subtitle": "Semana de carrera"}, {"date": "2026-10-20", "week": "16", "phase": "Carrera", "type": "easy", "session": "5 km easy + 4 strides", "pace": "5:55-6:30/km", "note": "Activar piernas sin fatigar.", "carga": "14-16 km incluyendo carrera", "prioridad": "Sábado = carrera", "subtitle": "Semana de carrera"}, {"date": "2026-10-21", "week": "16", "phase": "Carrera", "type": "rest", "session": "Descanso", "pace": "Sin carga", "note": "", "carga": "14-16 km incluyendo carrera", "prioridad": "Sábado = carrera", "subtitle": "Semana de carrera"}, {"date": "2026-10-22", "week": "16", "phase": "Carrera", "type": "quality", "session": "4 km: 2 km easy + 1 km ritmo objetivo + 1 km easy", "pace": "4:55-5:05/km", "note": "Último recordatorio de ritmo.", "carga": "14-16 km incluyendo carrera", "prioridad": "Sábado = carrera", "subtitle": "Semana de carrera"}, {"date": "2026-10-23", "week": "16", "phase": "Carrera", "type": "rest", "session": "Descanso total", "pace": "Sin carga", "note": "Dormir, hidratar, revisar zapatillas/Garmin.", "carga": "14-16 km incluyendo carrera", "prioridad": "Sábado = carrera", "subtitle": "Semana de carrera"}, {"date": "2026-10-24", "week": "16", "phase": "Carrera", "type": "race", "session": "MEDIA MARATÓN — 21.1 km", "pace": "Ver estrategia de carrera", "note": "Objetivo: sub-1:45. Km 1-5 controlado, correr de verdad desde el km 15.", "carga": "14-16 km incluyendo carrera", "prioridad": "Sábado = carrera", "subtitle": "Semana de carrera"}, {"date": "2026-10-25", "week": "16", "phase": "Carrera", "type": "rest", "session": "Descanso total", "pace": "Sin carga", "note": "Caminar suave si quieres. Celebra.", "carga": "14-16 km incluyendo carrera", "prioridad": "Sábado = carrera", "subtitle": "Semana de carrera"}];

const RACE_DATE = "2026-10-24";
const GOAL_TIME = "1:45:00";

const DEFAULT_PROFILE = {
  name: "Felipe",
  age: null,
  weeklyMileageBaseline: 40,
  experience: "recreational",
  goalDistanceKm: 21.1,
  goalRaceDate: RACE_DATE,
  targetFinishTime: GOAL_TIME,
  injuryHistory: "",
  units: "km",
};

const TYPE_META = {
  rest:    { label: "Descanso",     color: "#6b7280", bg: "#f2f4f7" },
  easy:    { label: "Easy",         color: "#0e8a82", bg: "#e3f4f2" },
  quality: { label: "Calidad",      color: "#d98b1f", bg: "#fbeed9" },
  long:    { label: "Fondo largo",  color: "#16233d", bg: "#e7ebf2" },
  gym_a:   { label: "Gym A",        color: "#7c3aed", bg: "#efe6fc" },
  gym_b:   { label: "Gym B",        color: "#7c3aed", bg: "#efe6fc" },
  race:    { label: "CARRERA",      color: "#c14a4a", bg: "#fbeaea" },
};

const PHASE_COLOR = {
  "Recuperación": "#6b7280",
  "Base": "#0e8a82",
  "Específica": "#d98b1f",
  "Taper": "#16233d",
  "Carrera": "#c14a4a",
};

/* ---------------- date helpers ---------------- */
function toISO(dt) {
  const y = dt.getFullYear();
  const m = String(dt.getMonth() + 1).padStart(2, "0");
  const d = String(dt.getDate()).padStart(2, "0");
  return y + "-" + m + "-" + d;
}
function daysBetween(a, b) {
  const A = new Date(a + "T00:00:00");
  const B = new Date(b + "T00:00:00");
  return Math.round((B - A) / 86400000);
}
function weekdayShort(iso) {
  const names = ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];
  return names[new Date(iso + "T00:00:00").getDay()];
}
function formatLong(iso) {
  const months = ["enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"];
  const names = ["Domingo","Lunes","Martes","Miércoles","Jueves","Viernes","Sábado"];
  const dt = new Date(iso + "T00:00:00");
  return names[dt.getDay()] + " " + dt.getDate() + " de " + months[dt.getMonth()];
}

/* ---------------- storage helpers (personal, not shared) ---------------- */
async function loadJSON(key, fallback) {
  try {
    const r = localStorage.getItem(key);
    return r ? JSON.parse(r) : fallback;
  } catch (e) {
    return fallback;
  }
}
async function saveJSON(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (e) {
    return false;
  }
}

/* =========================================================
   READINESS ENGINE  (mirrors PRD section 5)
   ========================================================= */
const SCALE5 = [
  { v: 1, label: "Muy mal" },
  { v: 2, label: "Mal" },
  { v: 3, label: "Regular" },
  { v: 4, label: "Bien" },
  { v: 5, label: "Muy bien" },
];
const PAIN_SCALE = [0,1,2,3,4,5,6,7,8,9,10];

function computeReadiness(c) {
  // higher raw value = better, except stress/soreness/fatigue where higher input = worse
  const sleep = c.sleep;            // 1-5, higher=better
  const energy = c.energy;          // 1-5, higher=better
  const stressInv = 6 - c.stress;   // invert: low stress = good
  const sorenessInv = 6 - c.soreness;
  const fatigueInv = 6 - c.priorFatigue;
  const weighted =
    sleep * 0.20 +
    energy * 0.10 +
    stressInv * 0.10 +
    sorenessInv * 0.15 +
    fatigueInv * 0.15 +
    // motivation folded into energy average per PRD simplification
    energy * 0.0;
  // normalize remaining weight (0.30) across sleep/energy blend to sum to 1.0 with above 0.70
  const base = (sleep + energy + stressInv + sorenessInv + fatigueInv) / 5; // 1-5 avg
  const score = Math.round(((base - 1) / 4) * 100); // scale 1-5 -> 0-100
  let band = "green";
  if (score < 40) band = "red";
  else if (score < 70) band = "yellow";
  return { score: Math.max(0, Math.min(100, score)), band };
}

function paingate(painLevel, recurringSameArea) {
  if (painLevel >= 7) return "block";
  if (painLevel >= 4 && recurringSameArea) return "caution";
  if (painLevel >= 1) return "monitor";
  return "none";
}

function getRecommendation(workout, checkin, recurringPain) {
  const gate = paingate(checkin.painLevel, recurringPain);
  const type = workout ? workout.type : "rest";

  if (gate === "block") {
    return {
      status: "danger",
      title: "Descansa — no lo compenses",
      body: "Un dolor de este nivel no se entrena. Pausa la sesión de hoy. Si es agudo, empeora, es recurrente, o te cambia la forma de correr, esto no es un diagnóstico — busca a un profesional.",
      action: "rest",
    };
  }
  if (gate === "caution") {
    return {
      status: "warn",
      title: "Este patrón de dolor pide cautela",
      body: "Misma zona de dolor varias veces en poco tiempo. Reduce a algo muy suave o movilidad hoy, y considera que un profesional lo revise si continúa.",
      action: "modify",
    };
  }

  if (!workout || type === "rest") {
    return { status: "ok", title: "Día de descanso", body: "Nada programado hoy. Movilidad suave si quieres, nada más.", action: "asplanned" };
  }
  if (type === "race") {
    return { status: "ok", title: "Día de carrera", body: "Confía en el plan. Los nervios no son lo mismo que la fatiga real.", action: "asplanned" };
  }

  const { band } = computeReadiness(checkin);

  if (band === "green") {
    return { status: "ok", title: "Sigue el plan tal cual", body: (workout.session || "Sesión de hoy") + " a " + (workout.pace || ""), action: "asplanned" };
  }

  if (band === "yellow") {
    if (type === "quality") return { status: "warn", title: "Baja a ritmo easy", body: "Misma distancia aprox., pero a ritmo fácil en vez de calidad.", action: "modify" };
    if (type === "long") return { status: "warn", title: "Fondo, pero fácil de verdad", body: "Mantén el kilometraje, corre en la parte más lenta de tu rango easy.", action: "modify" };
    if (type === "gym_a" || type === "gym_b") return { status: "warn", title: "Gym con menos carga", body: "Reduce una serie o el peso 15-20%.", action: "modify" };
    return { status: "warn", title: "Easy, un poco más corto", body: "Está bien recortar 15-20% la distancia de hoy.", action: "modify" };
  }

  // red
  if (type === "quality") return { status: "danger", title: "Cambia calidad por descanso", body: "Con esta fatiga, la calidad resta en vez de sumar. Descansa o trota muy suave 20-30 min.", action: "swap_rest" };
  if (type === "long") return { status: "danger", title: "Recorta el fondo ~30%", body: "Una de las pocas razones válidas para tocar el fondo. Corre completamente fácil.", action: "modify" };
  if (type === "gym_a" || type === "gym_b") return { status: "danger", title: "Salta el gym hoy", body: "Solo movilidad o core suave, 10 minutos.", action: "swap_rest" };
  return { status: "danger", title: "Descansa en vez de correr", body: "La fatiga acumulada es alta. El descanso de hoy vale más que los kilómetros.", action: "swap_rest" };
}

/* plan vs actual comparison for post-run review */
function compareRun(workout, actual) {
  if (!workout) {
    return "Carrera registrada. No había sesión planeada para hoy — buen extra.";
  }
  const lines = [];
  if (workout.distance_km_target && actual.distanceKm) {
    const diff = actual.distanceKm - workout.distance_km_target;
    if (Math.abs(diff) < 0.3) lines.push("Distancia cumplida.");
    else if (diff > 0) lines.push("Corriste " + diff.toFixed(1) + " km más de lo planeado.");
    else lines.push("Corriste " + Math.abs(diff).toFixed(1) + " km menos de lo planeado.");
  }
  if (actual.rpe != null) {
    if (actual.rpe <= 3) lines.push("Esfuerzo bajo — coherente con un día fácil.");
    else if (actual.rpe <= 6) lines.push("Esfuerzo moderado.");
    else lines.push("Esfuerzo alto — asegúrate que correspondía al tipo de sesión de hoy.");
  }
  if (actual.painDuring > 0 || actual.painAfter > 0) {
    lines.push("Hubo dolor durante o después de correr — anótalo en el registro de dolor para seguirle la pista.");
  } else {
    lines.push("Sin dolor reportado. Buena señal.");
  }
  return lines.join(" ");
}

/* =========================================================
   UI PRIMITIVES
   ========================================================= */
const S = {
  page: { minHeight: "100vh", background: "#f4f6f8", fontFamily: "'Inter','Poppins',sans-serif", paddingBottom: 84 },
  header: { background: "linear-gradient(135deg, #16233d 0%, #1f3a5f 60%, #0e8a82 140%)", color: "white", padding: "20px 16px 34px 16px" },
  card: { background: "white", borderRadius: 18, padding: "16px 16px", boxShadow: "0 2px 10px rgba(22,35,61,0.08)", border: "1px solid #eef0f3", marginBottom: 14 },
  h1: { fontFamily: "'Poppins',sans-serif", fontWeight: 700, color: "#16233d" },
  btnPrimary: { width: "100%", background: "#0e8a82", color: "white", border: "none", borderRadius: 16, padding: "15px 18px", fontSize: 15, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center", gap: 8 },
  btnGhost: { width: "100%", background: "#f2f4f7", color: "#16233d", border: "none", borderRadius: 16, padding: "13px 18px", fontSize: 14, fontWeight: 600 },
  pill: (bg, fg) => ({ fontSize: 11, fontWeight: 700, color: fg || "#fff", background: bg, borderRadius: 20, padding: "4px 10px", display: "inline-block" }),
  input: { width: "100%", padding: "12px 14px", borderRadius: 12, border: "1.5px solid #e3e6ec", fontSize: 14.5, fontFamily: "inherit", marginTop: 6, marginBottom: 14 },
  label: { fontSize: 12.5, fontWeight: 600, color: "#6b7280" },
};

const STATUS_META = {
  ok:     { color: "#0e8a82", bg: "#e3f4f2", icon: CheckCircle2 },
  warn:   { color: "#d98b1f", bg: "#fbeed9", icon: AlertTriangle },
  danger: { color: "#c14a4a", bg: "#fbeaea", icon: AlertTriangle },
};

function ScaleTapper({ options, value, onChange }) {
  return (
    <div style={{ display: "flex", gap: 8 }}>
      {options.map((o) => (
        <button
          key={o.v}
          onClick={() => onChange(o.v)}
          style={{
            flex: 1, padding: "12px 4px", borderRadius: 12, textAlign: "center",
            border: value === o.v ? "2px solid #0e8a82" : "1.5px solid #e3e6ec",
            background: value === o.v ? "#e3f4f2" : "#fff",
            fontWeight: value === o.v ? 700 : 500, fontSize: 12.5, color: "#16233d",
          }}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

function NumberDial({ max, value, onChange }) {
  const nums = Array.from({ length: max + 1 }, (_, i) => i);
  return (
    <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
      {nums.map((n) => (
        <button
          key={n}
          onClick={() => onChange(n)}
          style={{
            width: 30, height: 30, borderRadius: 8, fontSize: 12.5, fontWeight: 700,
            border: value === n ? "2px solid #c14a4a" : "1.5px solid #e3e6ec",
            background: value === n ? "#fbeaea" : "#fff",
            color: value === n ? "#c14a4a" : "#6b7280",
          }}
        >
          {n}
        </button>
      ))}
    </div>
  );
}

function BottomNav({ tab, setTab }) {
  const items = [
    { k: "today", icon: Home, label: "Hoy" },
    { k: "calendar", icon: CalendarIcon, label: "Plan" },
    { k: "pain", icon: HeartPulse, label: "Dolor" },
    { k: "profile", icon: User, label: "Perfil" },
  ];
  return (
    <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, background: "white", borderTop: "1px solid #eef0f3", display: "flex", padding: "8px 4px", boxShadow: "0 -2px 10px rgba(0,0,0,0.05)" }}>
      {items.map((it) => {
        const active = tab === it.k;
        return (
          <button key={it.k} onClick={() => setTab(it.k)} style={{ flex: 1, background: "none", border: "none", display: "flex", flexDirection: "column", alignItems: "center", gap: 3, padding: "6px 0", color: active ? "#0e8a82" : "#9aa3b2" }}>
            <it.icon size={20} />
            <span style={{ fontSize: 10, fontWeight: 700 }}>{it.label}</span>
          </button>
        );
      })}
    </div>
  );
}

/* =========================================================
   MAIN APP
   ========================================================= */
function RunCoachApp() {
  const [today] = useState(() => toISO(new Date()));
  const [tab, setTab] = useState("today");
  const [loaded, setLoaded] = useState(false);

  const [profile, setProfile] = useState(DEFAULT_PROFILE);
  const [plan, setPlan] = useState([]);
  const [checkins, setCheckins] = useState({});      // date -> checkin
  const [completed, setCompleted] = useState({});    // date -> actual
  const [painEntries, setPainEntries] = useState([]); // list

  const [checkinScreen, setCheckinScreen] = useState(null); // null | "quiz" | "result"
  const [qIndex, setQIndex] = useState(0);
  const [draftCheckin, setDraftCheckin] = useState({ sleep: 3, energy: 3, stress: 3, soreness: 3, priorFatigue: 3, painLevel: 0, painArea: "" });

  const [postRunOpen, setPostRunOpen] = useState(false);
  const [draftActual, setDraftActual] = useState({ distanceKm: "", durationMin: "", rpe: 5, felt: "ok", painDuring: 0, painAfter: 0, notes: "" });

  const [painFormOpen, setPainFormOpen] = useState(false);
  const [draftPain, setDraftPain] = useState({ area: "", scale: 3, context: "daily", notes: "" });

  /* ---- load persisted state on mount ---- */
  useEffect(() => {
    (async () => {
      const p = await loadJSON("profile", DEFAULT_PROFILE);
      const pl = await loadJSON("plan", SEED_PLAN);
      const ci = await loadJSON("checkins", {});
      const co = await loadJSON("completed", {});
      const pe = await loadJSON("painEntries", []);
      setProfile(p);
      setPlan(pl);
      setCheckins(ci);
      setCompleted(co);
      setPainEntries(pe);
      setLoaded(true);
    })();
  }, []);

  const todayWorkout = useMemo(() => plan.find((d) => d.date === today) || null, [plan, today]);
  const raceOffset = daysBetween(today, profile.goalRaceDate || RACE_DATE);
  const todayCheckin = checkins[today];

  const recurringPain = useMemo(() => {
    if (!draftPainAreaCheck(draftCheckin.painArea)) return false;
    const recent = painEntries.filter((p) => p.area === draftCheckin.painArea && daysBetween(p.date, today) <= 14);
    return recent.length >= 2;
  }, [painEntries, draftCheckin.painArea, today]);

  function draftPainAreaCheck(area) { return !!area; }

  async function persistProfile(next) { setProfile(next); await saveJSON("profile", next); }
  async function persistPlan(next) { setPlan(next); await saveJSON("plan", next); }
  async function persistCheckins(next) { setCheckins(next); await saveJSON("checkins", next); }
  async function persistCompleted(next) { setCompleted(next); await saveJSON("completed", next); }
  async function persistPain(next) { setPainEntries(next); await saveJSON("painEntries", next); }

  const questions = [
    { key: "sleep", title: "¿Cómo dormiste anoche?", icon: Moon, opts: SCALE5 },
    { key: "energy", title: "¿Nivel de energía ahora?", icon: Zap, opts: SCALE5 },
    { key: "stress", title: "¿Nivel de estrés hoy?", icon: Activity, opts: [1,2,3,4,5].map((v)=>({v, label: ["Muy bajo","Bajo","Medio","Alto","Muy alto"][v-1]})) },
    { key: "soreness", title: "¿Dolor muscular / agujetas?", icon: Activity, opts: [1,2,3,4,5].map((v)=>({v, label: ["Nada","Leve","Moderado","Notable","Fuerte"][v-1]})) },
    { key: "priorFatigue", title: "¿Fatiga de la sesión anterior?", icon: TrendingUp, opts: [1,2,3,4,5].map((v)=>({v, label: ["Nada","Leve","Moderada","Alta","Muy alta"][v-1]})) },
  ];

  function startCheckin() {
    setDraftCheckin({ sleep: 3, energy: 3, stress: 3, soreness: 3, priorFatigue: 3, painLevel: 0, painArea: "" });
    setQIndex(0);
    setCheckinScreen("quiz");
  }

  function answerQ(key, value) {
    setDraftCheckin((d) => ({ ...d, [key]: value }));
  }

  async function finishCheckin() {
    const rec = getRecommendation(todayWorkout, draftCheckin, recurringPain);
    const entry = { ...draftCheckin, date: today, recommendation: rec };
    const next = { ...checkins, [today]: entry };
    await persistCheckins(next);
    setCheckinScreen("result");
  }

  async function saveCompletedRun() {
    const actual = {
      ...draftActual,
      distanceKm: parseFloat(draftActual.distanceKm) || 0,
      durationMin: parseFloat(draftActual.durationMin) || 0,
      date: today,
    };
    const next = { ...completed, [today]: actual };
    await persistCompleted(next);
    if (actual.painDuring >= 4 || actual.painAfter >= 4) {
      const pe = [...painEntries, { id: "p" + Date.now(), date: today, area: "sin especificar (post-carrera)", scale: Math.max(actual.painDuring, actual.painAfter), context: "after_run", notes: draftActual.notes }];
      await persistPain(pe);
    }
    setPostRunOpen(false);
  }

  async function savePainEntry() {
    const pe = [...painEntries, { id: "p" + Date.now(), date: today, ...draftPain }];
    await persistPain(pe);
    setPainFormOpen(false);
    setDraftPain({ area: "", scale: 3, context: "daily", notes: "" });
  }

  const weekPlan = useMemo(() => {
    if (!todayWorkout) return [];
    return plan.filter((d) => d.week === todayWorkout.week);
  }, [plan, todayWorkout]);

  const paceCalc = useMemo(() => {
    const [h, m, s] = (profile.targetFinishTime || "1:45:00").split(":").map(Number);
    const totalMin = h * 60 + m + s / 60;
    const perKm = totalMin / (profile.goalDistanceKm || 21.1);
    const mm = Math.floor(perKm);
    const ss = Math.round((perKm - mm) * 60);
    return mm + ":" + String(ss).padStart(2, "0") + "/km";
  }, [profile.targetFinishTime, profile.goalDistanceKm]);

  if (!loaded) {
    return <div style={{ ...S.page, display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div style={{ color: "#6b7280", fontSize: 14 }}>Cargando tu plan...</div>
    </div>;
  }

  return (
    <div style={S.page}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@600;700&family=Inter:wght@400;500;600;700&display=swap');
        * { box-sizing: border-box; }
        body { margin: 0; }
        button { cursor: pointer; font-family: inherit; }
      `}</style>

      <div style={S.header}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <div style={{ fontSize: 11, letterSpacing: 1, color: "#9fd8d2", fontWeight: 700, textTransform: "uppercase" }}>
              {profile.name ? profile.name + " · " : ""}Running Coach
            </div>
            <div style={{ ...S.h1, fontSize: 19, color: "white", marginTop: 2 }}>
              {tab === "today" && "Hoy"}
              {tab === "calendar" && "Tu plan"}
              {tab === "pain" && "Dolor y recuperación"}
              {tab === "profile" && "Perfil"}
            </div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ ...S.h1, fontSize: 20, color: "white" }}>{raceOffset >= 0 ? raceOffset : 0}</div>
            <div style={{ fontSize: 10, color: "#9fd8d2" }}>días para la carrera</div>
          </div>
        </div>
      </div>

      <div style={{ padding: "0 16px", marginTop: -18 }}>

        {tab === "today" && (
          <TodayScreen
            today={today}
            todayWorkout={todayWorkout}
            todayCheckin={todayCheckin}
            completedToday={completed[today]}
            startCheckin={startCheckin}
            openPostRun={() => setPostRunOpen(true)}
            weekPlan={weekPlan}
          />
        )}

        {tab === "calendar" && (
          <CalendarScreen plan={plan} completed={completed} checkins={checkins} today={today} />
        )}

        {tab === "pain" && (
          <PainScreen painEntries={painEntries} openForm={() => setPainFormOpen(true)} />
        )}

        {tab === "profile" && (
          <ProfileScreen profile={profile} setProfile={persistProfile} paceCalc={paceCalc} raceOffset={raceOffset} />
        )}
      </div>

      {/* CHECK-IN MODAL */}
      {checkinScreen === "quiz" && (
        <Modal onClose={() => setCheckinScreen(null)}>
          <div style={{ display: "flex", gap: 6, marginBottom: 18 }}>
            {questions.map((_, i) => (
              <div key={i} style={{ flex: 1, height: 4, borderRadius: 2, background: i <= qIndex ? "#0e8a82" : "#e3e6ec" }} />
            ))}
          </div>
          {qIndex < questions.length ? (
            <>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
                {React.createElement(questions[qIndex].icon, { size: 20, color: "#0e8a82" })}
                <h3 style={{ ...S.h1, fontSize: 16.5, margin: 0 }}>{questions[qIndex].title}</h3>
              </div>
              <ScaleTapper
                options={questions[qIndex].opts.map((o) => ({ v: o.v, label: o.label }))}
                value={draftCheckin[questions[qIndex].key]}
                onChange={(v) => {
                  answerQ(questions[qIndex].key, v);
                  setTimeout(() => setQIndex(qIndex + 1), 150);
                }}
              />
            </>
          ) : (
            <>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
                <AlertTriangle size={20} color="#c14a4a" />
                <h3 style={{ ...S.h1, fontSize: 16.5, margin: 0 }}>¿Dolor que cambia tu pisada o técnica?</h3>
              </div>
              <div style={{ ...S.label, marginBottom: 6 }}>Nivel (0 = nada, 10 = muy fuerte)</div>
              <NumberDial max={10} value={draftCheckin.painLevel} onChange={(v) => answerQ("painLevel", v)} />
              {draftCheckin.painLevel > 0 && (
                <>
                  <div style={{ ...S.label, marginTop: 14, marginBottom: 6 }}>¿Dónde?</div>
                  <input style={S.input} placeholder="ej. rodilla derecha, fascia plantar..." value={draftCheckin.painArea} onChange={(e) => answerQ("painArea", e.target.value)} />
                </>
              )}
              <button style={S.btnPrimary} onClick={finishCheckin}>
                Ver recomendación <ChevronRight size={18} />
              </button>
            </>
          )}
        </Modal>
      )}

      {checkinScreen === "result" && checkins[today] && (
        <Modal onClose={() => setCheckinScreen(null)}>
          <ResultCard rec={checkins[today].recommendation} workout={todayWorkout} onClose={() => setCheckinScreen(null)} />
        </Modal>
      )}

      {/* POST-RUN MODAL */}
      {postRunOpen && (
        <Modal onClose={() => setPostRunOpen(false)}>
          <h3 style={{ ...S.h1, fontSize: 17, marginTop: 0 }}>Registrar carrera de hoy</h3>
          <div style={S.label}>Distancia (km)</div>
          <input style={S.input} type="number" step="0.1" value={draftActual.distanceKm} onChange={(e) => setDraftActual({ ...draftActual, distanceKm: e.target.value })} placeholder="8.1" />
          <div style={S.label}>Duración (min)</div>
          <input style={S.input} type="number" value={draftActual.durationMin} onChange={(e) => setDraftActual({ ...draftActual, durationMin: e.target.value })} placeholder="48" />
          <div style={S.label}>¿Cómo se sintió?</div>
          <ScaleTapper
            options={[{v:"great",label:"Genial"},{v:"good",label:"Bien"},{v:"ok",label:"Normal"},{v:"hard",label:"Duro"},{v:"bad",label:"Mal"}]}
            value={draftActual.felt}
            onChange={(v) => setDraftActual({ ...draftActual, felt: v })}
          />
          <div style={{ ...S.label, marginTop: 14 }}>RPE (esfuerzo percibido 0-10)</div>
          <NumberDial max={10} value={draftActual.rpe} onChange={(v) => setDraftActual({ ...draftActual, rpe: v })} />
          <div style={{ ...S.label, marginTop: 14 }}>Dolor durante (0-10)</div>
          <NumberDial max={10} value={draftActual.painDuring} onChange={(v) => setDraftActual({ ...draftActual, painDuring: v })} />
          <div style={{ ...S.label, marginTop: 14 }}>Dolor después (0-10)</div>
          <NumberDial max={10} value={draftActual.painAfter} onChange={(v) => setDraftActual({ ...draftActual, painAfter: v })} />
          <div style={{ ...S.label, marginTop: 14 }}>Notas (opcional)</div>
          <input style={S.input} value={draftActual.notes} onChange={(e) => setDraftActual({ ...draftActual, notes: e.target.value })} placeholder="Zapatillas, clima, sensaciones..." />
          <button style={S.btnPrimary} onClick={saveCompletedRun}>
            <Check size={18} /> Guardar
          </button>
        </Modal>
      )}

      {/* PAIN ENTRY MODAL */}
      {painFormOpen && (
        <Modal onClose={() => setPainFormOpen(false)}>
          <h3 style={{ ...S.h1, fontSize: 17, marginTop: 0 }}>Registrar dolor</h3>
          <div style={S.label}>Zona</div>
          <input style={S.input} value={draftPain.area} onChange={(e) => setDraftPain({ ...draftPain, area: e.target.value })} placeholder="ej. rodilla derecha" />
          <div style={S.label}>Escala (0-10)</div>
          <NumberDial max={10} value={draftPain.scale} onChange={(v) => setDraftPain({ ...draftPain, scale: v })} />
          <div style={{ ...S.label, marginTop: 14 }}>¿Cuándo?</div>
          <ScaleTapper
            options={[{v:"during_run",label:"Corriendo"},{v:"after_run",label:"Post-carrera"},{v:"daily",label:"Día a día"},{v:"rest",label:"En reposo"}]}
            value={draftPain.context}
            onChange={(v) => setDraftPain({ ...draftPain, context: v })}
          />
          <div style={{ ...S.label, marginTop: 14 }}>Notas</div>
          <input style={S.input} value={draftPain.notes} onChange={(e) => setDraftPain({ ...draftPain, notes: e.target.value })} placeholder="Opcional" />
          <button style={S.btnPrimary} onClick={savePainEntry}><Check size={18} /> Guardar</button>
        </Modal>
      )}

      <BottomNav tab={tab} setTab={setTab} />
    </div>
  );
}

/* =========================================================
   SCREENS
   ========================================================= */
function TodayScreen({ today, todayWorkout, todayCheckin, completedToday, startCheckin, openPostRun, weekPlan }) {
  const tMeta = todayWorkout ? TYPE_META[todayWorkout.type] : TYPE_META.rest;
  return (
    <>
      <div style={{ ...S.card, borderTop: "4px solid " + tMeta.color }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <span style={S.pill(tMeta.bg, tMeta.color)}>{tMeta.label}</span>
          {todayWorkout && todayWorkout.type === "race" && <Flag size={20} color="#c14a4a" />}
        </div>
        <h2 style={{ ...S.h1, fontSize: 18, margin: "10px 0 4px 0" }}>
          {todayWorkout ? todayWorkout.session : "Sin sesión planeada hoy"}
        </h2>
        {todayWorkout && <div style={{ color: "#0e8a82", fontWeight: 700, fontSize: 14 }}>{todayWorkout.pace}</div>}
        {todayWorkout && todayWorkout.note ? (
          <p style={{ color: "#4a5468", fontSize: 13.3, marginTop: 8, lineHeight: 1.5 }}>{todayWorkout.note}</p>
        ) : null}
      </div>

      {!todayCheckin && (
        <button style={S.btnPrimary} onClick={startCheckin}>
          <Sparkles size={18} /> Hacer check-in de hoy
        </button>
      )}

      {todayCheckin && (
        <div style={{ ...S.card, background: STATUS_META[todayCheckin.recommendation.status].bg, border: "none" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            {React.createElement(STATUS_META[todayCheckin.recommendation.status].icon, { size: 18, color: STATUS_META[todayCheckin.recommendation.status].color })}
            <span style={{ fontWeight: 700, color: "#16233d", fontSize: 14.5 }}>{todayCheckin.recommendation.title}</span>
          </div>
          <p style={{ fontSize: 13, color: "#3a4457", marginTop: 6, marginBottom: 0 }}>{todayCheckin.recommendation.body}</p>
        </div>
      )}

      {!completedToday && todayWorkout && todayWorkout.type !== "rest" && (
        <button style={S.btnGhost} onClick={openPostRun}>Registrar carrera de hoy</button>
      )}
      {completedToday && (
        <div style={S.card}>
          <div style={{ fontSize: 12, color: "#6b7280", marginBottom: 4 }}>Registrado hoy</div>
          <div style={{ ...S.h1, fontSize: 15 }}>{completedToday.distanceKm} km · {completedToday.durationMin} min · RPE {completedToday.rpe}</div>
          <p style={{ fontSize: 13, color: "#3a4457", marginTop: 8 }}>{compareRun(todayWorkout, completedToday)}</p>
        </div>
      )}

      {weekPlan.length > 0 && (
        <div style={S.card}>
          <div style={{ ...S.h1, fontSize: 14, marginBottom: 10 }}>Esta semana</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 7 }}>
            {weekPlan.map((d) => {
              const m = TYPE_META[d.type];
              const isToday = d.date === today;
              return (
                <div key={d.date} style={{ display: "flex", alignItems: "center", gap: 10, padding: "6px 8px", borderRadius: 10, background: isToday ? "#f2f5f8" : "transparent", border: isToday ? "1.5px solid #16233d" : "1.5px solid transparent" }}>
                  <span style={{ fontSize: 10.5, fontWeight: 700, color: m.color, background: m.bg, borderRadius: 6, padding: "3px 6px", minWidth: 56, textAlign: "center" }}>{weekdayShort(d.date)}</span>
                  <span style={{ fontSize: 12, color: "#16233d", flex: 1 }}>{d.session}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </>
  );
}

function CalendarScreen({ plan, completed, checkins, today }) {
  const weeks = useMemo(() => {
    const byWeek = {};
    plan.forEach((d) => {
      if (!byWeek[d.week]) byWeek[d.week] = [];
      byWeek[d.week].push(d);
    });
    return Object.keys(byWeek).sort((a, b) => Number(a) - Number(b)).map((k) => ({ week: k, days: byWeek[k] }));
  }, [plan]);

  const [openWeek, setOpenWeek] = useState(null);

  useEffect(() => {
    const wk = plan.find((d) => d.date === today);
    if (wk) setOpenWeek(wk.week);
  }, [plan, today]);

  return (
    <>
      {weeks.map((w) => {
        const phase = w.days[0].phase;
        const isOpen = openWeek === w.week;
        return (
          <div key={w.week} style={S.card}>
            <button onClick={() => setOpenWeek(isOpen ? null : w.week)} style={{ width: "100%", background: "none", border: "none", display: "flex", justifyContent: "space-between", alignItems: "center", padding: 0 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <span style={S.pill(PHASE_COLOR[phase])}>Sem {w.week}</span>
                <span style={{ fontSize: 13, color: "#6b7280" }}>{phase}</span>
              </div>
              <ChevronRight size={18} color="#6b7280" style={{ transform: isOpen ? "rotate(90deg)" : "none" }} />
            </button>
            {isOpen && (
              <div style={{ marginTop: 12, display: "flex", flexDirection: "column", gap: 7 }}>
                {w.days.map((d) => {
                  const m = TYPE_META[d.type];
                  const isToday = d.date === today;
                  const done = completed[d.date];
                  const ci = checkins[d.date];
                  return (
                    <div key={d.date} style={{ display: "flex", alignItems: "center", gap: 8, padding: "7px 8px", borderRadius: 10, background: isToday ? "#f2f5f8" : "transparent" }}>
                      <span style={{ fontSize: 10.5, fontWeight: 700, color: m.color, background: m.bg, borderRadius: 6, padding: "3px 6px", minWidth: 52, textAlign: "center" }}>{weekdayShort(d.date)}</span>
                      <span style={{ fontSize: 12, color: "#16233d", flex: 1 }}>{d.session}</span>
                      {done && <CheckCircle2 size={15} color="#0e8a82" />}
                      {ci && !done && React.createElement(STATUS_META[ci.recommendation.status].icon, { size: 14, color: STATUS_META[ci.recommendation.status].color })}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        );
      })}
    </>
  );
}

function PainScreen({ painEntries, openForm }) {
  const sorted = [...painEntries].sort((a, b) => (a.date < b.date ? 1 : -1));
  const areas = {};
  sorted.forEach((p) => { areas[p.area] = (areas[p.area] || 0) + 1; });
  const flagged = Object.entries(areas).filter(([, n]) => n >= 3);

  return (
    <>
      <button style={S.btnPrimary} onClick={openForm}><Plus size={18} /> Registrar dolor</button>

      {flagged.length > 0 && (
        <div style={{ ...S.card, background: "#fbeaea", border: "none", marginTop: 14 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <AlertTriangle size={18} color="#c14a4a" />
            <span style={{ fontWeight: 700, color: "#7a2b2b", fontSize: 14 }}>Patrón detectado</span>
          </div>
          <p style={{ fontSize: 13, color: "#7a2b2b", marginTop: 6, marginBottom: 0 }}>
            {flagged.map(([a, n]) => a + " (" + n + " veces)").join(", ")} — esto no es un diagnóstico, pero un dolor recurrente en la misma zona vale la pena revisarlo con un profesional.
          </p>
        </div>
      )}

      <div style={{ marginTop: 14 }}>
        {sorted.length === 0 && <div style={{ ...S.card, textAlign: "center", color: "#9aa3b2", fontSize: 13 }}>Sin registros de dolor. Así se ve cuando todo va bien.</div>}
        {sorted.map((p) => (
          <div key={p.id} style={S.card}>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <span style={{ fontWeight: 700, color: "#16233d", fontSize: 13.5 }}>{p.area}</span>
              <span style={S.pill(p.scale >= 7 ? "#c14a4a" : p.scale >= 4 ? "#d98b1f" : "#0e8a82")}>{p.scale}/10</span>
            </div>
            <div style={{ fontSize: 12, color: "#6b7280", marginTop: 4 }}>{p.date} · {p.context}</div>
            {p.notes && <div style={{ fontSize: 12.5, color: "#4a5468", marginTop: 6 }}>{p.notes}</div>}
          </div>
        ))}
      </div>
    </>
  );
}

function ProfileScreen({ profile, setProfile, paceCalc, raceOffset }) {
  const [local, setLocal] = useState(profile);
  useEffect(() => setLocal(profile), [profile]);

  function field(key, label, type) {
    return (
      <>
        <div style={S.label}>{label}</div>
        <input style={S.input} type={type || "text"} value={local[key] !== undefined && local[key] !== null ? local[key] : ""} onChange={(e) => setLocal({ ...local, [key]: e.target.value })} />
      </>
    );
  }

  return (
    <>
      <div style={S.card}>
        <div style={{ ...S.h1, fontSize: 15, marginBottom: 4 }}>Meta de carrera</div>
        <div style={{ display: "flex", gap: 10, marginTop: 10 }}>
          <div style={{ flex: 1, background: "#f2f5f8", borderRadius: 12, padding: "10px 12px" }}>
            <div style={{ fontSize: 10, color: "#6b7280" }}>Objetivo</div>
            <div style={{ ...S.h1, fontSize: 16 }}>{profile.targetFinishTime}</div>
          </div>
          <div style={{ flex: 1, background: "#f2f5f8", borderRadius: 12, padding: "10px 12px" }}>
            <div style={{ fontSize: 10, color: "#6b7280" }}>Ritmo objetivo</div>
            <div style={{ ...S.h1, fontSize: 16 }}>{paceCalc}</div>
          </div>
          <div style={{ flex: 1, background: "#f2f5f8", borderRadius: 12, padding: "10px 12px" }}>
            <div style={{ fontSize: 10, color: "#6b7280" }}>Faltan</div>
            <div style={{ ...S.h1, fontSize: 16 }}>{raceOffset >= 0 ? raceOffset : 0}d</div>
          </div>
        </div>
      </div>

      <div style={S.card}>
        <div style={{ ...S.h1, fontSize: 15, marginBottom: 10 }}>Datos personales</div>
        {field("name", "Nombre")}
        {field("age", "Edad", "number")}
        {field("weeklyMileageBaseline", "Kilometraje semanal base (km)", "number")}
        {field("goalDistanceKm", "Distancia objetivo (km)", "number")}
        {field("goalRaceDate", "Fecha de carrera", "date")}
        {field("targetFinishTime", "Tiempo objetivo (h:mm:ss)")}
        <div style={S.label}>Historial de lesiones</div>
        <textarea
          style={{ ...S.input, minHeight: 70, resize: "vertical" }}
          value={local.injuryHistory || ""}
          onChange={(e) => setLocal({ ...local, injuryHistory: e.target.value })}
        />
        <button style={S.btnPrimary} onClick={() => setProfile(local)}>
          <Check size={18} /> Guardar cambios
        </button>
      </div>
    </>
  );
}

function ResultCard({ rec, workout, onClose }) {
  const meta = STATUS_META[rec.status];
  return (
    <>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
        {React.createElement(meta.icon, { size: 22, color: meta.color })}
        <span style={{ fontSize: 12, fontWeight: 700, color: meta.color, textTransform: "uppercase", letterSpacing: 0.5 }}>Recomendación</span>
      </div>
      <h2 style={{ ...S.h1, fontSize: 19, margin: "6px 0 8px 0" }}>{rec.title}</h2>
      <p style={{ color: "#3a4457", fontSize: 14.5, lineHeight: 1.55 }}>{rec.body}</p>
      {workout && (
        <div style={{ background: "#f2f5f8", borderRadius: 12, padding: "10px 12px", marginTop: 10 }}>
          <div style={{ fontSize: 11, color: "#6b7280" }}>Sesión original del plan</div>
          <div style={{ fontWeight: 700, color: "#16233d", fontSize: 14 }}>{workout.session}</div>
        </div>
      )}
      <button style={{ ...S.btnPrimary, marginTop: 16, background: "#16233d" }} onClick={onClose}>
        <RotateCcw size={16} /> Volver a hoy
      </button>
    </>
  );
}

function Modal({ children, onClose }) {
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(22,35,61,0.5)", display: "flex", alignItems: "flex-end", zIndex: 50 }} onClick={onClose}>
      <div
        style={{ background: "white", borderTopLeftRadius: 22, borderTopRightRadius: 22, padding: "20px 18px 26px 18px", width: "100%", maxHeight: "88vh", overflowY: "auto" }}
        onClick={(e) => e.stopPropagation()}
      >
        <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 6 }}>
          <button onClick={onClose} style={{ background: "#f2f4f7", border: "none", borderRadius: 20, width: 32, height: 32, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <X size={16} color="#6b7280" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}


ReactDOM.createRoot(document.getElementById('root')).render(<RunCoachApp />);
